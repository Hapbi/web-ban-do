# NOVA HOME — Demo tổng hợp
Web ASP.NET Core MVC .NET 8, dựng mới từ 3 bộ mã được cung cấp.

## Đã tổng hợp / nâng cấp
- Giữ tinh thần hiệu ứng từ `effect-web-ready`: reveal on scroll, marquee, magnetic button, glow, gradient, sticky/visual cards.
- Trang bán hàng mới: home, catalog, tìm kiếm, lọc, chi tiết.
- Giỏ hàng riêng: quản lý số lượng, xóa, xóa tất cả, mã ưu đãi demo, tiến độ miễn phí vận chuyển, tổng tiền, tiện ích và nút thanh toán thử nghiệm.
- Khách chưa đăng nhập bị đưa tới màn hình chọn vai trò trước khi thêm vào giỏ.
- Admin: dashboard doanh thu, biểu đồ 7 ngày, KPI, top sản phẩm, đơn hàng, quản lý sản phẩm.
- Staff: trung tâm bán hàng, hàng chờ xử lý, doanh số, quy trình 4 bước, gợi ý sản phẩm.
- Nút `Xem thông số` cố ý trả về trạng thái lỗi demo.
- Nút thanh toán chỉ mô phỏng lỗi/chế độ thử nghiệm, không có giao dịch thật.
- Không cần SQL/Internet để chạy; dữ liệu mẫu nằm trong `Models/DemoStore.cs`.

## Chạy
```bash
dotnet restore
dotnet run
```
Mở URL localhost được terminal in ra.

## Demo role
`/Account/Login`
- Customer: giao diện mua hàng
- Staff: `/Staff`
- Admin: `/Admin`

Đây là bản demo frontend + MVC logic. Có thể thay `DemoStore` bằng EF Core/SQL Server ở bước tiếp theo.
