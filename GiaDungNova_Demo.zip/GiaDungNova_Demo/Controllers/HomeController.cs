using GiaDungNova_Demo.Models;
using Microsoft.AspNetCore.Mvc;

namespace GiaDungNova_Demo.Controllers;
public class HomeController : Controller
{
    private readonly DemoStore _store;
    public HomeController(DemoStore store) => _store = store;
    public IActionResult Index() => View(_store.Products.Take(6).ToList());
    public IActionResult Logout() { HttpContext.Session.Clear(); return RedirectToAction("Index"); }
}
