using GiaDungNova_Demo.Models;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace GiaDungNova_Demo.Controllers;
public class CartController : Controller
{
    private readonly DemoStore _store;
    private const string Key="DEMO_CART";
    private List<int> GetCart() => JsonSerializer.Deserialize<List<int>>(HttpContext.Session.GetString(Key) ?? "[]") ?? new();
    private void Save(List<int> ids) => HttpContext.Session.SetString(Key, JsonSerializer.Serialize(ids));
    public IActionResult Index()
    {
        var ids=GetCart();
        var lines=ids.GroupBy(x=>x).Select(g=>new CartLine(_store.Products.First(p=>p.Id==g.Key),g.Count())).ToList();
        return View(lines);
    }
    [HttpPost] public IActionResult Add(int id) {
        var role=HttpContext.Session.GetString("ROLE");
        if (string.IsNullOrEmpty(role)) return RedirectToAction("Login","Account",new{reason="cart",returnUrl="/Products/Detail/"+id});
        var ids=GetCart(); ids.Add(id); Save(ids);
        TempData["Toast"]="Đã thêm sản phẩm vào giỏ hàng."; return Redirect(Request.Headers.Referer.ToString());
    }
    [HttpPost] public IActionResult Update(int id,int quantity) {
        var ids=GetCart(); ids.RemoveAll(x=>x==id); for(int i=0;i<Math.Clamp(quantity,0,20);i++) ids.Add(id); Save(ids); return RedirectToAction("Index");
    }
    [HttpPost] public IActionResult Remove(int id) { var ids=GetCart(); ids.Remove(id); Save(ids); return RedirectToAction("Index"); }
    [HttpPost] public IActionResult Clear() { Save(new()); return RedirectToAction("Index"); }
    public IActionResult Checkout() => Json(new {ok=false,message="Thanh toán đang ở CHẾ ĐỘ THỬ NGHIỆM. Demo chưa kết nối cổng thanh toán thật."});
}
public record CartLine(Product Product,int Quantity)
{
    public decimal Total => Product.Price*Quantity;
}
