using GiaDungNova_Demo.Models;
using Microsoft.AspNetCore.Mvc;
namespace GiaDungNova_Demo.Controllers;
public class StaffController : Controller
{
    private readonly DemoStore _store;
    public StaffController(DemoStore store)=>_store=store;
    private bool IsStaff()=>HttpContext.Session.GetString("ROLE")=="Staff";
    public IActionResult Index(){ if(!IsStaff()) return RedirectToAction("Login","Account"); return View(_store); }
}
