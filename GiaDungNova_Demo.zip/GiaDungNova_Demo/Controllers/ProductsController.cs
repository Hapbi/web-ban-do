using GiaDungNova_Demo.Models;
using Microsoft.AspNetCore.Mvc;

namespace GiaDungNova_Demo.Controllers;
public class ProductsController : Controller
{
    private readonly DemoStore _store;
    public ProductsController(DemoStore store) => _store = store;
    public IActionResult Index(string? q, string? category)
    {
        var data = _store.Products.AsEnumerable();
        if (!string.IsNullOrWhiteSpace(q)) data = data.Where(p => p.Name.Contains(q, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(category)) data = data.Where(p => p.Category == category);
        ViewBag.Query=q; ViewBag.Category=category; ViewBag.Categories=_store.Products.Select(x=>x.Category).Distinct().ToList();
        return View(data.ToList());
    }
    public IActionResult Detail(int id) => View(_store.Products.FirstOrDefault(x=>x.Id==id));
    public IActionResult Specs(int id) => Json(new { ok=false, message="Module thông số kỹ thuật đang lỗi trong bản demo. Vui lòng thử lại sau.", productId=id });
}
