using Microsoft.AspNetCore.Mvc;
namespace GiaDungNova_Demo.Controllers;
public class AccountController : Controller
{
    public IActionResult Login(string? reason,string? returnUrl) { ViewBag.Reason=reason; ViewBag.ReturnUrl=returnUrl; return View(); }
    [HttpPost] public IActionResult Login(string username,string role,string? returnUrl)
    {
        HttpContext.Session.SetString("ROLE", role);
        HttpContext.Session.SetString("USER", string.IsNullOrWhiteSpace(username)?"Demo User":username);
        if(role=="Admin") return RedirectToAction("Index","Admin");
        if(role=="Staff") return RedirectToAction("Index","Staff");
        return RedirectToAction("Index","Home");
    }
}
