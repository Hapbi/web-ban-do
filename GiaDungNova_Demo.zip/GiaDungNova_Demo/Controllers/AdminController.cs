using GiaDungNova_Demo.Models;
using Microsoft.AspNetCore.Mvc;
namespace GiaDungNova_Demo.Controllers;
public class AdminController : Controller
{
    private readonly DemoStore _store;
    public AdminController(DemoStore store)=>_store=store;
    private bool IsAdmin()=>HttpContext.Session.GetString("ROLE")=="Admin";
    public IActionResult Index(){ if(!IsAdmin()) return RedirectToAction("Login","Account"); return View(_store); }
    public IActionResult Products(){ if(!IsAdmin()) return RedirectToAction("Login","Account"); return View(_store.Products); }
}
