namespace GiaDungNova_Demo.Models;

public record Product(int Id, string Name, string Category, string Brand, decimal Price, decimal OldPrice, int Stock, string Badge, string Accent, string Description);
public record Order(int Id, string Code, string Customer, DateTime Date, decimal Total, string Status, string Staff);
public class DemoStore
{
    public List<Product> Products { get; } = new()
    {
        new(1,"Nồi chiên không dầu Nova Air 6L","Nhà bếp","Nova",1890000,2290000,18,"-17%","violet","Công nghệ Rapid Air, lòng nồi chống dính, 8 chương trình nấu."),
        new(2,"Robot hút bụi Nova Clean X5","Vệ sinh","Nova",4290000,4990000,7,"Bán chạy","cyan","Lập bản đồ phòng, lau ướt, tự quay về dock sạc."),
        new(3,"Máy lọc không khí PureHome S3","Điện lạnh","PureHome",3190000,3590000,12,"Mới","blue","Bộ lọc 3 lớp, cảm biến bụi mịn và chế độ ngủ."),
        new(4,"Máy xay đa năng KitchenPro 900","Nhà bếp","KitchenPro",1290000,1590000,25,"-19%","orange","Cối thủy tinh 1.5L, 5 tốc độ, lưỡi thép 6 cánh."),
        new(5,"Ấm siêu tốc GlassHeat 1.7L","Nhà bếp","GlassHeat",590000,790000,34,"Hot","pink","Thân kính chịu nhiệt, tự ngắt khi sôi."),
        new(6,"Máy sấy tóc Ionic Pro 2200","Chăm sóc","Ionic Pro",790000,990000,16,"-20%","purple","Ion âm, 3 mức nhiệt, đầu sấy tạo kiểu."),
        new(7,"Nồi cơm điện SmartCook 1.8L","Nhà bếp","SmartCook",1090000,1390000,9,"Ưu đãi","green","Lòng nồi dày, hẹn giờ 24h, giữ ấm tự động."),
        new(8,"Máy hút bụi cầm tay Flex V8","Vệ sinh","Flex",2190000,2590000,5,"Sắp hết","red","Pin 45 phút, đầu hút khe và chổi mềm.")
    };
    public List<Order> Orders { get; } = new()
    {
        new(1001,"NV-260921","Nguyễn Minh Anh",DateTime.Today.AddDays(-1),4290000,"Đã giao","Linh"),
        new(1002,"NV-260922","Trần Quốc Huy",DateTime.Today.AddHours(-5),3190000,"Đang xử lý","Minh"),
        new(1003,"NV-260923","Lê Thu Hà",DateTime.Today.AddHours(-3),1890000,"Đã xác nhận","Linh"),
        new(1004,"NV-260924","Phạm Đức Long",DateTime.Today.AddDays(-2),6490000,"Đã giao","An"),
        new(1005,"NV-260925","Hoàng Ngọc Mai",DateTime.Today.AddHours(-1),2380000,"Chờ xử lý","Minh")
    };
}
